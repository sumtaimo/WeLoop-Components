import React from "react";
import * as RadixAvatar from "@radix-ui/react-avatar";
import { IconUser16, IconUser161, IconBag16, IconBanking16, IconPlus16 } from "../Icon/Icon";

// ─── Types ────────────────────────────────────────────────────────────────────
export type AvatarType =
  | "noProfile"     // person silhouette, ring border, light bg
  | "noProfileFill" // person silhouette, gray filled (32px only in Figma)
  | "items"         // items / purpose icon, ring border
  | "bank"          // bank icon, ring border
  | "office"        // circular photo — supply src  ← upgraded to Radix Avatar
  | "textProfile"   // initials text, gray filled
  | "chipLead"      // chip-style: icon or text, gray filled
  | "addMore";      // noProfile base + plus badge in bottom-right

export type AvatarSize = 20 | 24 | 32;

export interface AvatarProps {
  /** Visual type */
  type?: AvatarType;
  /** Pixel size — 20 | 24 | 32 */
  size?: AvatarSize;
  /** Photo URL — used when type="office" */
  src?: string;
  /** Alt text for photo */
  alt?: string;
  /** Initials — used when type="textProfile" or "chipLead" */
  text?: string;
  /** Custom icon node — used when type="chipLead" */
  icon?: React.ReactNode;
  onClick?: () => void;
  className?: string;
}

// ─── Size tokens ──────────────────────────────────────────────────────────────
const SIZE_CONFIG: Record<AvatarSize, {
  px: number;
  border: number;
  iconPx: number;
  badgePx: number;
  fontSize: number;
  lineHeight: string;
}> = {
  20: { px: 20, border: 1.25, iconPx: 12, badgePx: 8,  fontSize: 11.25, lineHeight: "10px" },
  24: { px: 24, border: 1.5,  iconPx: 14, badgePx: 10, fontSize: 13.5,  lineHeight: "12px" },
  32: { px: 32, border: 2,    iconPx: 20, badgePx: 13, fontSize: 14,    lineHeight: "16px" },
};

// ─── Colour constants (from Figma token values) ───────────────────────────────
const CLR_BG_LIGHT  = "#F9FAFB";  // bg-default-secondary (ring types)
const CLR_BG_FILLED = "#E5E5E5";  // bg-disabled-secondary (fill types)
const CLR_BORDER    = "#9CA3AF";  // border-selected-onselected
const CLR_ICON      = "#9CA3AF";  // icon stroke / fill
const CLR_TEXT      = "#A3A3A3";  // text-default-secondary

// ─── SVG Icons (delegated to Icon library) ────────────────────────────────────

const PersonIcon      = ({ size }: { size: number }) => <IconUser16  size={size} color={CLR_ICON} />;
const PersonFilledIcon = ({ size }: { size: number }) => <IconUser161 size={size} color={CLR_ICON} />;
const ItemsIcon        = ({ size }: { size: number }) => <IconBag16   size={size} color={CLR_ICON} />;
const BankIcon         = ({ size }: { size: number }) => <IconBanking16 size={size} color={CLR_ICON} />;
const PlusIcon         = ({ size }: { size: number }) => <IconPlus16  size={size} color="white" />;

// ─── Component ────────────────────────────────────────────────────────────────

export function Avatar({
  type      = "noProfile",
  size      = 24,
  src,
  alt       = "",
  text      = "A",
  icon,
  onClick,
  className,
}: AvatarProps) {
  const cfg    = SIZE_CONFIG[size];
  const isRing = ["noProfile", "items", "bank", "addMore", "office"].includes(type);

  const containerStyle: React.CSSProperties = {
    position:       "relative",
    display:        "inline-flex",
    alignItems:     "center",
    justifyContent: "center",
    width:          cfg.px,
    height:         cfg.px,
    borderRadius:   9999,
    flexShrink:     0,
    boxSizing:      "border-box",
    overflow:       type === "office" ? "hidden" : undefined,
    background:     type === "office" ? "#D1D5DB" : isRing ? CLR_BG_LIGHT : CLR_BG_FILLED,
    border:         isRing ? `${cfg.border}px solid ${CLR_BORDER}` : "none",
    cursor:         onClick ? "pointer" : undefined,
  };

  // ── "office" — uses Radix Avatar for proper image load/fallback ───────────
  if (type === "office") {
    return (
      <RadixAvatar.Root
        style={containerStyle}
        className={className}
        onClick={onClick}
      >
        <RadixAvatar.Image
          src={src}
          alt={alt}
          style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
        />
        {/* Fallback: shown while image loads or if src is missing/broken */}
        <RadixAvatar.Fallback
          delayMs={src ? 300 : 0}
          style={{
            width:          "100%",
            height:         "100%",
            display:        "flex",
            alignItems:     "center",
            justifyContent: "center",
            background:     "#D1D5DB",
          }}
        >
          {/* Show initials from alt text, or silhouette icon */}
          {alt ? (
            <span style={{
              fontFamily: "Inter, sans-serif",
              fontWeight: 600,
              fontSize:   cfg.fontSize,
              color:      "#6B7280",
              userSelect: "none",
            }}>
              {alt.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase()}
            </span>
          ) : (
            <PersonIcon size={cfg.iconPx} />
          )}
        </RadixAvatar.Fallback>
      </RadixAvatar.Root>
    );
  }

  // ── Text-based (textProfile, chipLead without icon) ──
  if (type === "textProfile" || (type === "chipLead" && !icon)) {
    return (
      <div style={containerStyle} className={className} onClick={onClick}>
        <span style={{
          fontFamily: "Inter, sans-serif",
          fontWeight: 500,
          fontSize:   cfg.fontSize,
          lineHeight: cfg.lineHeight,
          color:      CLR_TEXT,
          userSelect: "none",
        }}>
          {text.slice(0, 2).toUpperCase()}
        </span>
      </div>
    );
  }

  // ── chipLead with custom icon ──
  if (type === "chipLead" && icon) {
    return (
      <div style={containerStyle} className={className} onClick={onClick}>
        <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center" }}>
          {icon}
        </span>
      </div>
    );
  }

  // ── noProfileFill ──
  if (type === "noProfileFill") {
    return (
      <div style={containerStyle} className={className} onClick={onClick}>
        <PersonFilledIcon size={cfg.iconPx} />
      </div>
    );
  }

  // ── addMore ──
  if (type === "addMore") {
    return (
      <div style={containerStyle} className={className} onClick={onClick}>
        <PersonIcon size={cfg.iconPx} />
        <span style={{
          position:       "absolute",
          bottom:         -Math.floor(cfg.badgePx * 0.2),
          right:          -Math.floor(cfg.badgePx * 0.2),
          width:          cfg.badgePx,
          height:         cfg.badgePx,
          borderRadius:   9999,
          background:     "#6B7280",
          display:        "flex",
          alignItems:     "center",
          justifyContent: "center",
          border:         "1.5px solid #F9FAFB",
          boxSizing:      "border-box",
        }}>
          <PlusIcon size={Math.round(cfg.badgePx * 0.65)} />
        </span>
      </div>
    );
  }

  // ── noProfile ──
  if (type === "noProfile") {
    return (
      <div style={containerStyle} className={className} onClick={onClick}>
        <PersonIcon size={cfg.iconPx} />
      </div>
    );
  }

  // ── items ──
  if (type === "items") {
    return (
      <div style={containerStyle} className={className} onClick={onClick}>
        <ItemsIcon size={cfg.iconPx} />
      </div>
    );
  }

  // ── bank ──
  return (
    <div style={containerStyle} className={className} onClick={onClick}>
      <BankIcon size={cfg.iconPx} />
    </div>
  );
}
